## goproxy-vps (a tls1.3/http2 and quic secure proxy)
[![Release](https://img.shields.io/badge/%20git.io-goproxy-blue.svg?style=social)](https://github.com/phuslu/goproxy/releases)

* 讨论区 https://github.com/phuslu/goproxy/issues?q=sort:updated-desc+is:open

## 文档
* 简易教程 https://github.com/phuslu/goproxy/issues/1470
* 配置介绍 https://github.com/phuslu/goproxy/blob/server.vps/goproxy-vps.toml
* 编译步骤 https://github.com/phuslu/goproxy/blob/wiki/HowToBuild.md
